package myapp.chessfinderapp.repository;

import org.json.JSONObject;

import java.util.HashMap;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface iApiCalls {

    @POST("/register")
    Call<JSONObject> register(@Body HashMap<String, Object> map);

    //Send the username and password via hashmap
    //Returns a chess user JsonObject 
    @POST("/login")
    Call<ChessUser> login(@Body HashMap<String, String> map);
}

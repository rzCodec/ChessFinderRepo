package myapp.chessfinderapp.repository;

import androidx.lifecycle.MutableLiveData;

import org.json.JSONObject;

import java.util.HashMap;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class API_Repository {
    private MutableLiveData<ChessUser> live_chess_user;
    private MutableLiveData<JSONObject> registrationObject;

    private iApiCalls api;
    private Call<JSONObject> registerCall;
    private Call<ChessUser> loginCall;

    private static final String EMAIL = "email";
    private static final String USERNAME = "username";
    private static final String PASSWORD = "password";

    public API_Repository() {
        api = RetrofitClient.getRetrofitInstance().create(iApiCalls.class);
        live_chess_user = new MutableLiveData<>();
        //registerCall = api.register();
        
       // mRequestCall = mRestful_API.get_article_content();
       // articles = new MutableLiveData<>();
    }


    /**
     * @param email
     * @param password
     * @return a chess user object which is then passed to the activity
     */
    public void login(String email, String password) {
       //Make hashmap and put the username and password
        HashMap<String, String> loginMap = new HashMap<>();
        loginMap.put(EMAIL, email);
        loginMap.put(PASSWORD, password);
        loginCall = api.login(loginMap);

        //Make the network call and return a chess user object
        //Use clone method to make multiple login calls if necessary within a single activity instance
        loginCall.clone().enqueue(new Callback<ChessUser>() {
            @Override
            public void onResponse(Call<ChessUser> call, Response<ChessUser> response) {
                live_chess_user.setValue(response.body());
            }

            @Override
            public void onFailure(Call<ChessUser> call, Throwable t) {
                live_chess_user.setValue(null);
            }
        });
    }

    /**
     * Register a new user and return a message via json object
     * @param email
     * @param username
     * @param password
     */
    public void register(String email, String username, String password) {
        HashMap<String, Object> map = new HashMap<>();
        map.put(EMAIL, email);
        map.put(USERNAME, username);
        map.put(PASSWORD, password);
        registerCall = api.register(map);

        //Make the registration call
        registerCall.enqueue(new Callback<JSONObject>() {
            @Override
            public void onResponse(Call<JSONObject> call, Response<JSONObject> response) {
                registrationObject.setValue(response.body());
            }

            @Override
            public void onFailure(Call<JSONObject> call, Throwable t) {
                registrationObject.setValue(null);
            }
        });

    }

    public MutableLiveData<ChessUser> getLiveChessuser() {
        return live_chess_user;
    }
    public MutableLiveData<JSONObject> getRegistrationObject() { return registrationObject; }
}
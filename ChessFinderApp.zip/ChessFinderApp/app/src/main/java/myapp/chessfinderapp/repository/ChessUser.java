package myapp.chessfinderapp.repository;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

import org.json.JSONObject;

public class ChessUser implements Parcelable {

    @SerializedName("user_email")
    private String email;

    private String password;

    @SerializedName("username")
    private String userName;

    @SerializedName("ChessData")
    private String chessDataObjectAsString;



    /*
    @SerializedName("y_coordinate")
    private double y_coordinate;

    @SerializedName("x_coordinate")
    private double x_coordinate;

    @SerializedName("rating")
    private int rating;

    @SerializedName("wins")
    private int wins;

    @SerializedName("loses")
    private int loses;*/


    //===============================
    private ChessUser(Parcel parcel) {
        this.email = parcel.readString();
        this.userName = parcel.readString();
        this.password = parcel.readString();
        this.chessDataObjectAsString = parcel.readString();
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {

    }
}
package myapp.chessfinderapp.view_model;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;

import org.json.JSONObject;

import myapp.chessfinderapp.repository.API_Repository;
import myapp.chessfinderapp.repository.ChessUser;

public class LoginAndRegisterViewModel extends ViewModel {
    private API_Repository api_repository;

    public LoginAndRegisterViewModel() {
        api_repository = new API_Repository();
    }

    public void login(String email, String password) {
        api_repository.login(email, password);
    }

    public void logout(String email) {

    }

    public void register(String email, String username, String password) {
        api_repository.register(email, username, password);
    }

    public LiveData<ChessUser> returnSuccessfulLogin_Details() {
        return api_repository.getLiveChessuser();
    }

    public LiveData<JSONObject> returnSuccessfulRegistration() {
        return api_repository.getRegistrationObject();
    }
}

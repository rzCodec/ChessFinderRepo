package myapp.chessfinderapp.repository;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

public class ChessUser implements Parcelable {

    @SerializedName("user_email")
    private String email;

    private String password;

    @SerializedName("username")
    private String userName;

    @SerializedName("ChessData")
    private String chessDataObjectAsString;

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public String getUserName() {
        return userName;
    }

    public String getChessDataObjectAsString() {
        return chessDataObjectAsString;
    }

    public ChessUser(String email,
                     String password,
                     String userName,
                     String chessDataObjectAsString) {

        this.email = email;
        this.password = password;
        this.userName = userName;
        this.chessDataObjectAsString = chessDataObjectAsString;
    }

    /*
    @SerializedName("y_coordinate")
    private double y_coordinate;

    @SerializedName("x_coordinate")
    private double x_coordinate;

    @SerializedName("rating")
    private int rating;

    @SerializedName("wins")
    private int wins;

    @SerializedName("loses")
    private int loses;*/


    //===============================
    private ChessUser(Parcel parcel) {
        this.email = parcel.readString();
        this.userName = parcel.readString();
        this.password = parcel.readString();
        this.chessDataObjectAsString = parcel.readString();
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {

    }

    public static final Parcelable.Creator<ChessUser> CREATOR = new Parcelable.Creator<ChessUser>() {
        public ChessUser createFromParcel(Parcel in) {
            return new ChessUser(in); //Refer to the private Subject Constructor
        }

        public ChessUser[] newArray(int size) {
            return new ChessUser[size];
        }
    };
}